export const slotValues = {
    day: "",              // e.g., "Monday"
    startTime: "",             // start time e.g., "08:00"
    startIsAm: "AM",      // AM/PM for start
    endTime: "",          // end time e.g., "10:00"
    endIsAm: "AM",        // AM/PM for end
  };
  
export const priceValue = {
    price: "",
  };
  