export const loginValues = {
  email: "",
  password: "",
};
export const forgetValues = {
  email: "",
};

export const emailVerificationValues = {
  otp: ["","","","",""],
};

export const ChangedValues = {
 password:"",
 confirmpassword:"",
};


export const updatePasswordValues = {
  password: "",
  newPassword:"",
  confirmpassword: "",
};