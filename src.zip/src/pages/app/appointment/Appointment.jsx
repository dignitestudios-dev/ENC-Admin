import AppointmentList from '../../../components/app/appointment/AppointmentList'

export default function Appointment() {
  return (
    <div>
        <AppointmentList/>
    </div>
  )
}
