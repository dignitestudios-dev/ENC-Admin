import UserList from "../../../components/app/user/UserList";

export default function User() {
  return (
    <div>
      <UserList/>
    </div>
  )
}
