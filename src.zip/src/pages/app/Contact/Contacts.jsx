import ContactList from "../../../components/app/Contact/ContactList";

export default function Contact() {
  return (
    <div>
      <ContactList />
    </div>
  );
}
